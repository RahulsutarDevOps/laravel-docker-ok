<?php

return [
    'fuelTypeList' => ['' => '','Diesel' => 'Diesel', 'EV'=>'EV', 'Hybrid/Diesel'=>'Hybrid/Diesel', 'Hybrid/Petrol'=>'Hybrid/Petrol', 'Hybrid/Petrol PHEV'=>'Hybrid/Petrol PHEV', 'Unleaded petrol' => 'Unleaded petrol', 'NA' => 'NA'
    ],

    'engineTypeList' => ['' => '', 'Euro III diesel' => 'Euro III diesel', 'Euro IV diesel' => 'Euro IV diesel', 'Euro V diesel' => 'Euro V diesel', 'Euro VI diesel (Adblue)' => 'Euro VI diesel (Adblue)', 'EV' => 'EV', 'Hybrid diesel/EV' => 'Hybrid diesel/EV', 'Hybrid petrol/EV' => 'Hybrid petrol/EV', 'PHEV petrol/EV' => 'PHEV petrol/EV', 'Petrol' => 'Petrol', 'NA' => 'NA'
    ],
];