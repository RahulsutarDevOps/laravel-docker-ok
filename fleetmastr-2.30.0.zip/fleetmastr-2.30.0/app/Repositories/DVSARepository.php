<?php
namespace App\Repositories;

use Auth;
use \Carbon\Carbon;
use \Illuminate\Support\Facades\DB;
use App\Custom\Repositories\EloquentRepositoryAbstract;

class DVSARepository extends EloquentRepositoryAbstract {
    public function __construct($data)
    {
        
    }
}