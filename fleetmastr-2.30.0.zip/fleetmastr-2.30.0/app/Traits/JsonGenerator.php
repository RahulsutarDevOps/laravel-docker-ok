<?php
namespace App\Traits;

use Storage;
use Image;
use App\Models\User;
use Spatie\MediaLibrary\Media;
use StdClass;
use Carbon\Carbon;
use App\Models\Defect;
use App\Models\Survey;
use App\Models\DefectHistory;
use App\Models\TemporaryImage;

trait JsonGenerator
{
	protected function getAllJson(){
		
	}
}