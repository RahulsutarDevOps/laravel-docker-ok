<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReportDownloadVehicleRegion extends Model
{
    protected $table = 'report_download_vehicle_regions';
}
