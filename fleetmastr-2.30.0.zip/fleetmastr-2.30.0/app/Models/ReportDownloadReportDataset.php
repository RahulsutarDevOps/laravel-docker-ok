<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReportDownloadReportDataset extends Model
{
    protected $table = 'report_download_report_dataset';
}
