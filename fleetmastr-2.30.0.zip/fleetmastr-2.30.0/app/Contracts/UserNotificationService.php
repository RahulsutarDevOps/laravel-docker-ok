<?php

namespace App\Contracts;

interface UserNotificationService
{

}